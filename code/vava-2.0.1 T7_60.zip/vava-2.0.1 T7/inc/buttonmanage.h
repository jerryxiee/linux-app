#ifndef _BUTTON_MANAGE_H_
#define _BUTTON_MANAGE_H_

void *buttionmanage_pth(void *data); 
void *keysync_pth(void *data);
void *keyaddstation_pth(void *data);
void *buzzer_manage_pth(void *data);
	
#endif

