#ifndef _ERR_LOG_H_
#define _ERR_LOG_H_

int Err_Log(char *str);
int Err_Info(char *str);

#endif

