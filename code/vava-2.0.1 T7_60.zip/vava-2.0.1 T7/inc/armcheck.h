#ifndef _ARM_CHECK_H_
#define _ARM_CHECK_H_

void *ArmCheck_v1_pth(void *data);

#endif
