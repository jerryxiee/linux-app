#ifndef _USB_OVERLOAD_CHECK_H_
#define _USB_OVERLOAD_CHECK_H_

void *UsbOverLoadCheck_pth(void *data);

#endif