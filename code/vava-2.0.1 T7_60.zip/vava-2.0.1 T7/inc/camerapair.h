#ifndef _CAMERA_PAIR_H_
#define _CAMERA_PAIR_H_

void *camerapair_pth(void *data);

#endif
