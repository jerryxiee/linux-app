#ifndef _DEV_DISCOVERY_H_
#define _DEV_DISCOVERY_H_

void *devdiscovery_pth(void *data);

#endif

