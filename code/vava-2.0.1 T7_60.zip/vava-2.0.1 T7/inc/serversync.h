#ifndef _PAIR_SYNC_H_
#define _PAIR_SYNC_H_

void *PairSync_pth(void *data);
void *StatusSync_pth(void *data);

#endif
