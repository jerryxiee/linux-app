#ifndef _CC1310_UPGRADE_H_
#define _CC1310_UPGRADE_H_

int vStartCC1310Upgrade();

#endif
